import scipy.misc
import cv2

dir = "../data/test/" 
if __name__ == "__main__":
  